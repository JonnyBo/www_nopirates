<?php

return [

    'class' => 'edgardmessias\db\firebird\Connection',
    'dsn' => 'firebird:dbname=188.93.210.100/53051:c:\dbs\nopirates.fdb;charset=utf8',
    'username' => 'admin',
    'password' => 'ybvlf14njh',
    //'charset' => 'utf8',

    //'class' => 'yii\db\Connection',
    //'dsn' => 'mysql:host=localhost;dbname=nopirates',
    //'username' => 'nopirates',
    //'password' => 'bydfkbl',
    'charset' => 'utf8',

    // Schema cache options (for production environment)
    //'enableSchemaCache' => true,
    //'schemaCacheDuration' => 60,
    //'schemaCache' => 'cache',
];
